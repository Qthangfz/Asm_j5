package com.poly.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.poly.Dao.SanPhamDao;
import com.poly.Model.SanPham;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CookieService {

    @Autowired
    HttpServletRequest request;

    @Autowired
    HttpServletResponse response;

    private ObjectMapper objectMapper = new ObjectMapper();

    public Cookie get(String name) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name)) {
                    return cookie;
                }
            }
        }
        return null;
    }

    public String getValue(String name) {
        var cookie = get(name);
        if (cookie == null) {
            return null;
        }
        return cookie.getValue();
    }

    public Cookie add(String name, String value, int hours) {
        Cookie cookie = new Cookie(name, value);
        cookie.setMaxAge(hours * 60 * 60);
        cookie.setPath("/");
        response.addCookie(cookie);
        return cookie;
    }

    public void remove(String name) {
        Cookie cookie = new Cookie(name, null);
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);
    }

    // Thêm sản phẩm vào danh sách vừa xem và lưu vào cookie
    public void addProductToRecentlyViewed(String cookieName, SanPham sanPham) {
        try {
            String productId = sanPham.getMasanpham();
            String cookieValue = getValue(cookieName);
            List<String> productIds;

            if (cookieValue != null && !cookieValue.isEmpty()) {
                productIds = new ArrayList<>(Arrays.asList(URLDecoder.decode(cookieValue, StandardCharsets.UTF_8.name()).split(",")));
                if (!productIds.contains(productId)) {
                    productIds.add(productId);
                }
            } else {
                productIds = new ArrayList<>();
                productIds.add(productId);
            }

            String newCookieValue = URLEncoder.encode(String.join(",", productIds), StandardCharsets.UTF_8.name());
            add(cookieName, newCookieValue, 72); // Lưu trong 30 ngày (30 * 24 = 720 giờ)
            System.out.println("Product added to recently viewed: " + productId);
            System.out.println("New cookie value: " + newCookieValue);

            // Log to ensure cookie is added correctly
            Cookie addedCookie = get(cookieName);
            System.out.println("Cookie after adding: " + (addedCookie != null ? addedCookie.getValue() : "null"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // Lấy danh sách sản phẩm từ cookie
    public List<SanPham> getRecentlyViewedProducts(String cookieName, SanPhamDao spDao) {
        List<SanPham> recentlyViewedProducts = new ArrayList<>();
        try {
            String cookieValue = getValue(cookieName);
            if (cookieValue != null && !cookieValue.isEmpty()) {
                List<String> productIds = Arrays.asList(URLDecoder.decode(cookieValue, StandardCharsets.UTF_8.name()).split(","));
                for (String productId : productIds) {
                    SanPham sanPham = spDao.findByMasanpham(productId);
                    if (sanPham != null) {
                        recentlyViewedProducts.add(sanPham);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Recently viewed products count: " + recentlyViewedProducts.size());
        return recentlyViewedProducts;
    }
}
