package com.poly.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.poly.Model.DonHang;
import com.poly.Model.SanPham;
import com.poly.Model.TaiKhoan;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

 
@Repository
public interface  DonHangDao  extends JpaRepository<DonHang, String> {
	 @Query("SELECT dh FROM DonHang dh WHERE dh.taikhoan = :taikhoan ORDER BY dh.ngaydathang DESC")
	DonHang findLatestByTaikhoan(@Param("taikhoan") TaiKhoan taikhoan);
	 
	 DonHang findFirstByTaikhoanOrderByNgaydathangDesc( TaiKhoan taikhoan);
	 
	 List<DonHang> findByTaikhoan (@Param ("taikhoan") TaiKhoan taikhoan);
	 
	 @Query(value = "SELECT COALESCE(SUM(dh.giatridonhang), 0) " + "FROM donhang dh "
				+ "WHERE DATEPART(week, dh.ngaydathang) = DATEPART(week, GETDATE()) "
				+ "AND DATEPART(year, dh.ngaydathang) = DATEPART(year, GETDATE())", nativeQuery = true)
		Float findWeeklyRevenue();

		@Query(value = "SELECT COALESCE(SUM(dh.giatridonhang), 0) " + "FROM donhang dh "
				+ "WHERE DATEPART(week, dh.ngaydathang) = DATEPART(week, DATEADD(week, -1, GETDATE())) "
				+ "AND DATEPART(year, dh.ngaydathang) = DATEPART(year, DATEADD(week, -1, GETDATE()))", nativeQuery = true)
		Float findLastWeekRevenue();

		@Query("SELECT COUNT(d) FROM DonHang d "
				+ "WHERE DATEPART(week, d.ngaydathang) = DATEPART(week, DATEADD(WEEK, -1, CURRENT_DATE)) "
				+ "AND YEAR(d.ngaydathang) = YEAR(CURRENT_DATE)")
		Float countOrdersInLastWeek();

		@Query("SELECT COUNT(d) FROM DonHang d " + "WHERE DATEPART(week, d.ngaydathang) = DATEPART(week, CURRENT_DATE) "
				+ "AND YEAR(d.ngaydathang) = YEAR(CURRENT_DATE)")
		Float countOrdersInCurrentWeek();

	//
//		@Query(value = "SELECT TOP 1 d1.sanpham " +
//	            "FROM DonHangChiTiet d1 " +
//	            "JOIN d1.donhang d2 " +
//	            "WHERE DATEPART(WEEK, d2.ngaydathang) = DATEPART(WEEK, CURRENT_TIMESTAMP) " +
//	            "AND YEAR(d2.ngaydathang) = YEAR(CURRENT_TIMESTAMP) " +
//	            "GROUP BY d1.sanpham " +
//	            "ORDER BY SUM(d1.soluong) DESC")
	//Optional<SanPham> findTopSellingProductOfCurrentWeek();
	//	
		// @Query(value = "SELECT d1.sanpham " +
//	               "FROM DonHangChiTiet d1 " +
//	               "JOIN d1.donhang d2 " +
//	               "WHERE DATEPART(WEEK, d2.ngaydathang) = DATEPART(WEEK, CURRENT_TIMESTAMP) " +
//	               "AND YEAR(d2.ngaydathang) = YEAR(CURRENT_TIMESTAMP) " +
//	               "GROUP BY d1.sanpham " +
//	               "ORDER BY SUM(d1.soluong) DESC")
	//Optional<SanPham> findTopSellingProductOfCurrentWeek();
//		    
		@Query(value = "SELECT SUM(d1.soluong) as tongsoluong " + "FROM DonHangChiTiet d1 " + "JOIN d1.donhang d2 "
				+ "WHERE DATEPART(WEEK, d2.ngaydathang) = DATEPART(WEEK, CURRENT_TIMESTAMP) "
				+ "AND YEAR(d2.ngaydathang) = YEAR(CURRENT_TIMESTAMP) " + "AND d1.sanpham = ?1 " + "GROUP BY d1.sanpham "
				+ "ORDER BY SUM(d1.soluong) DESC")
		Optional<Long> findTotalQuantitySoldOfTopProduct(SanPham sanpham);

		@Query(value = "SELECT d1.sanpham " + "FROM DonHangChiTiet d1 " + "JOIN d1.donhang d2 "
				+ "WHERE DATEPART(WEEK, d2.ngaydathang) = DATEPART(WEEK, CURRENT_TIMESTAMP) - 1 "
				+ "AND YEAR(d2.ngaydathang) = YEAR(CURRENT_TIMESTAMP) " + "GROUP BY d1.sanpham "
				+ "ORDER BY SUM(d1.soluong) DESC")
		Optional<SanPham> findTopSellingProductOfPreviousWeek();
}
