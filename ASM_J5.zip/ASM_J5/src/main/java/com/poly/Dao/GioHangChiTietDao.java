package com.poly.Dao;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
 
import com.poly.Model.GioHangChiTiet;

public interface GioHangChiTietDao extends JpaRepository<GioHangChiTiet, Integer> {

    @Query("SELECT gh FROM GioHangChiTiet gh WHERE gh.taikhoan.taikhoan = :taikhoan")
    List<GioHangChiTiet> findByTaikhoan(@Param("taikhoan") String taikhoan);

    @Transactional
    @Modifying
    @Query(value = "insert into giohangchitiet (taikhoan, masanpham, soluong) values (:taikhoan, :masanpham, :soluong)", nativeQuery = true)
    void insertGioHangChiTiet(@Param("taikhoan") String taikhoan, @Param("masanpham") String masanpham,
                              @Param("soluong") int soluong);


    @Query("SELECT SUM(gct.soluong * gct.sanpham.dongia) FROM GioHangChiTiet gct WHERE gct.taikhoan.taikhoan = :taikhoan")
    Float calculateSubtotal(@Param("taikhoan") String taikhoan);

    @Query("SELECT SUM(gct.soluong) FROM GioHangChiTiet gct WHERE gct.taikhoan.taikhoan = :taikhoan")
    Integer calculateTotalQuantity(@Param("taikhoan") String taikhoan);

    @Query("SELECT COUNT(DISTINCT gct.sanpham.masanpham) FROM GioHangChiTiet gct WHERE gct.taikhoan.taikhoan = :taikhoan")
    Integer countDistinctProductCodes(@Param("taikhoan") String taikhoan);

    @Query("SELECT COUNT(gct) FROM GioHangChiTiet gct WHERE gct.taikhoan.taikhoan = :taikhoan")
    Integer countItems(@Param("taikhoan") String taikhoan);

    @Modifying
    @Transactional
    @Query("UPDATE GioHangChiTiet g SET g.soluong = :quantity WHERE g.id = :id")
    void updateQuantity(@Param("id") Integer id, @Param("quantity") Integer quantity);

    @Query("SELECT SUM(g.sanpham.trongluong * g.soluong) FROM GioHangChiTiet g WHERE g.taikhoan.taikhoan = :taikhoan")
    Float sumWeightByAccount(@Param("taikhoan") String taikhoan);
}