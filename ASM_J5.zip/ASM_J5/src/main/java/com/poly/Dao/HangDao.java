package com.poly.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.poly.Model.Hang;
import com.poly.Model.LoaiPhuKien;
 

 
@Repository
public interface  HangDao  extends JpaRepository<Hang, String> {
	 List<Hang> findAll();
}
