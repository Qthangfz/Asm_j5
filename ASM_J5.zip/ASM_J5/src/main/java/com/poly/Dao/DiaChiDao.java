package com.poly.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.poly.Model.DangNhap;
import com.poly.Model.DiaChi;
import com.poly.Model.TaiKhoan;

public interface DiaChiDao extends JpaRepository<DiaChi, Integer> {

	  Optional<DiaChi> findByTaikhoanAndMadiachi(TaiKhoan taiKhoan, Integer madiachi);
	  List<DiaChi> findByTaikhoan(TaiKhoan taikhoan);

}
	
 