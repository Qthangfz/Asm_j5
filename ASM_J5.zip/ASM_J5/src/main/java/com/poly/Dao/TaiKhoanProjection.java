package com.poly.Dao;

public interface TaiKhoanProjection {
    String getUsername();
    boolean getVaitro();
}