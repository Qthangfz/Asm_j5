package com.poly.Dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.poly.Model.DangNhap;
import com.poly.Model.TaiKhoan;

public interface TaiKhoanDao extends JpaRepository<TaiKhoan, String> {
	 boolean existsByEmail(String email);
	 
	 @Query("SELECT t.taikhoan as username, t.vaitro as vaitro FROM TaiKhoan t WHERE t.taikhoan = :taikhoan")
	    TaiKhoanProjection findProjectedByUsername(@Param("taikhoan") String taiKhoan);
	
	 
}
	
 