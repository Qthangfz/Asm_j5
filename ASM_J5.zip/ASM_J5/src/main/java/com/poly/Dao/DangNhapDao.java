package com.poly.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.poly.Model.DangNhap;

public interface DangNhapDao extends JpaRepository<DangNhap, String> {

	  @Query("SELECT d FROM DangNhap d WHERE (d.taikhoan = :identifier OR d.email = :identifier) AND d.matkhau = :password")
	    DangNhap findByUsernameOrEmailAndPassword(@Param("identifier") String identifier, @Param("password") String password);
}
	
 