package com.poly.Dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.poly.Model.Hang;
import com.poly.Model.LoaiPhuKien;
import com.poly.Model.SanPham;

 
@Repository
public interface  SanPhamDao  extends JpaRepository<SanPham, String> {
	SanPham findByMasanpham(String id);
	//Vì asm khi lọc sẽ có nhiều trường hợp như là chỉ lọc loại, loại với hãng, hãng với giá, hoặc chỉ lọc giá 
	//nên viết nhiều hàm truy vấn
    Page<SanPham> findByLoaiphukienAndHangAndDongiaBetween(LoaiPhuKien loaiphukien, Hang hang, Double giaTu, Double giaDen, Pageable pageable);
    Page<SanPham> findByLoaiphukienAndHang(LoaiPhuKien loaiphukien, Hang hang, Pageable pageable);
    Page<SanPham> findByLoaiphukien(LoaiPhuKien loaiphukien, Pageable pageable);
    Page<SanPham> findByHang(Hang hang, Pageable pageable);
    Page<SanPham> findByHangAndDongiaBetween(Hang hang, Double giaTu, Double giaDen, Pageable pageable);
    Page<SanPham> findByHangInAndDongiaBetween(List<Hang> hangList, Double giaTu, Double giaDen, Pageable pageable);
    Page<SanPham> findByDongiaBetween(Double giaTu, Double giaDen, Pageable pageable);
    Page<SanPham> findByHangIn(List<Hang> hangList, Pageable pageable);
    Page<SanPham> findByLoaiphukienAndHangIn(LoaiPhuKien loaiphukien, List<Hang> hangList, Pageable pageable);
    Page<SanPham> findByLoaiphukienAndHangInAndDongiaBetween(LoaiPhuKien loaiphukien, List<Hang> hangList, Double giaTu, Double giaDen, Pageable pageable);
    Page<SanPham> findByLoaiphukienAndDongiaBetween(LoaiPhuKien loaiphukien, Double giaTu, Double giaDen, Pageable pageable);

    //Kết hợp nhiều thứ như phân trang, sort, tìm theo khoảng giá, tìm theo loại, loại chỉ tìm 1 loại, tìm theo hãng, nhiều hãng
    
    //CÓ áp dụng viết câu truy vấn JPQL (@Query)
    @Query("SELECT DISTINCT sp.hang FROM SanPham sp WHERE sp.loaiphukien.maloai = :maloai")
    List<Hang> findDistinctHangsByLoaiphukien(@Param("maloai") String maloai);
}
