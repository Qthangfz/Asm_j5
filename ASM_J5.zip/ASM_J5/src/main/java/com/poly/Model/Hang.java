package com.poly.Model;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "hang")
public class Hang {

    @Id
    @Column(name = "mahang", length = 7)
    private String mahang;

    @Column(name = "tenhang", nullable = false, length = 50)
    private String tenhang;

    @Column(name = "logohang", length = 50)
    private String logohang;

    @Column(name = "kichhoat", nullable = false)
    private Boolean kichhoat = true;

    @OneToMany(mappedBy = "hang")
    private List<SanPham> sanphams;

    // Getters and Setters
}