package com.poly.Model;

import java.util.List;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "loaiphukien")
public class LoaiPhuKien {

    @Id
    @Column(name = "maloai", length = 7)
    private String maloai;

    @Column(name = "tenloai", nullable = false, length = 50)
    private String tenloai;

    @Column(name = "logoloai", length = 50)
    private String logoloai;

    @Column(name = "kichhoat", nullable = false)
    private Boolean kichhoat = true;

    @OneToMany(mappedBy = "loaiphukien")
    private List<SanPham> sanphams;

    // Getters and Setters
}