package com.poly.Model;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.poly.Dao.DonHangChiTietDao;
import com.poly.Dao.DonHangDao;
import com.poly.Dao.GioHangChiTietDao;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "donhang")
public class DonHang {

	@Id
	@Column(name = "madonhang",columnDefinition = "varchar(7)", length = 7)
	private String madonhang;

	@ManyToOne
	@JoinColumn(name = "taikhoan")
	private TaiKhoan taikhoan;
	
    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ngaydathang", columnDefinition = "datetime default getdate()")
	private Date ngaydathang;
    
    @Temporal(TemporalType.TIMESTAMP)
   	@Column(name = "ngayhuy", nullable = true)
   	private Date ngayhuy;
    
    @Temporal(TemporalType.TIMESTAMP)
   	@Column(name = "ngaygui", nullable = true)
   	private Date ngaygui;
    
    @Temporal(TemporalType.TIMESTAMP)
   	@Column(name = "ngaygiao", nullable = true)
   	private Date ngaygiao;


	@Column(name = "giatridonhang")
	private Float giatridonhang;

	@Column(name = "trangthaidonhang", length = 20, nullable = false)
	private String trangthaidonhang;

	 @Column(name = "ghichu", columnDefinition = "nvarchar(255)")
	private String ghichu;

	 @Column(name = "diachinhanhang", columnDefinition = "nvarchar(255)")
	private String diachinhanhang;
	
	@Column(name = "cuocvanchuyen")
	private Float cuocvanchuyen;

	@OneToMany(mappedBy = "donhang")
	private List<DonHangChiTiet> donhangchitiets;
	
//	foreach dh.donhangchitiets var item
//	
//	item.sanpham.hinhanhs[0].tenhinhanh item.sanpham.tensanpham  item.sanpham.loaiphukien.tenloai 
//	item.sanpham.hang.tenhang  item.dongia.   item.soluong  tổng  item.dongia*item.soluong
	
	

}
