package com.poly.Model;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "taikhoan")
public class DangNhap {

    @Id
    @Column(name = "taikhoan", length = 20)
    private String taikhoan;
    @NotBlank(message = "Xin nhập tài khoản hoặc email")
    @Column(name = "matkhau", length = 50)
    private String matkhau;

    @Column(name = "kichhoat", nullable = false)
    private Boolean kichhoat = true;

    @Column(name = "vaitro", nullable = false)
    private Boolean vaitro = false;

    @Column(name = "email", length = 100)
    private String email;
    @Transient
private boolean rememberme = false;
    @Transient
    @NotBlank(message = "Xin nhập mật khẩu")
    private String identifier;
}