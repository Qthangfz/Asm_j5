package com.poly.Model;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "taikhoan")
public class TaiKhoan {

    @Id
    @Column(name = "taikhoan", length = 20)
//    @NotBlank(message="Vui lòng nhập tài khoản")
//    @Pattern(regexp = "^[a-zA-Z0-9]{5,20}$", message = "Tài khoản chỉ được chứa các chữ cái và số, từ 5 đến 20 ký tự")
    private String taikhoan;


    
//    @NotEmpty(message="Vui lòng nhập họ tên")
//   @Pattern(regexp = "^[\\p{L}]+(\\s[\\p{L}]+)*$",  message = "Vui lòng nhập họ tên hợp lệ")
    @Column(name = "hoten", length = 50)
    private String hoten;

  
//    @NotEmpty(message="Vui lòng nhập mật khẩu")
//    @Pattern( regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()\\-_=+{};:,<.>]).{8,50}$", 
//  	    message = "Mật khẩu phải chứa ít nhất một chữ hoa, một chữ thường, một số và một ký tự đặc biệt, từ 8 ký tự"
//   	)
    @Column(name = "matkhau", length = 50)
    private String matkhau;
    
    @Transient
    private String matkhaucu;
    
    @Transient
    private String matkhaumoi;

    @Transient
    private String xacnhanmatkhau;
    
 
    @Column(name = "anhdaidien", length = 50  )
    private String anhdaidien="defaultavatar.jpg";

    @Column(name = "kichhoat", nullable = false)
    private Boolean kichhoat = true;

    @Column(name = "vaitro", nullable = false)
    private Boolean vaitro = false;


    @Column(name = "email", length = 100)
    private String email;
    
//    @NotEmpty(message="Vui lòng nhập số điện thoại")
//    @Pattern( regexp = "^(0|\\+84|84)[1-9]{1}+[0-9]{8,9}$", 
//	    message = "Vui lòng nhập số điện thoại hợp lệ"	)
    @Column(name = "sodienthoai", length = 15)
    private String sodienthoai;

    @Column(name = "landangnhapcuoi", columnDefinition = "datetime default getdate()")
    private Date landangnhapcuoi;



    @OneToMany(mappedBy = "taikhoan")
    private List<DonHang> donhangs;

    @OneToMany(mappedBy = "taikhoan")
    private List<DanhGia> danhgias;

    
    @OneToMany(mappedBy = "taikhoan")
    private List<DiaChi> diachis;
    
    @OneToMany(mappedBy = "taikhoan")
    private List<YeuThich> yeuthichs;

 

   
}