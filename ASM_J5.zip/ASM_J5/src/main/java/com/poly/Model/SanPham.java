package com.poly.Model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name = "sanpham")
public class SanPham {

    @Id
    @Column(name = "masanpham", length = 7)
    private String masanpham;

    @Column(name = "tensanpham", length = 255)
    private String tensanpham;

    @ManyToOne
    @JoinColumn(name = "maloai")
    private LoaiPhuKien loaiphukien;

    @ManyToOne
    @JoinColumn(name = "mahang")
    private Hang hang;

    @Column(name = "thongtinsanpham")
    private String thongtinsanpham;
    @Column(name = "mota")
    private String mota;

    @Column(name = "trongluong")
    private Float trongluong;

    @Column(name = "dongia")
    private Float dongia;

    @Column(name = "soluong")
    private Integer soluong;

    @Column(name = "ngaychinhsua", columnDefinition = "datetime default getdate()")
    private Date ngaychinhsua;

    @Column(name = "soluongdaban", columnDefinition = "int default 0")
    private Integer soluongdaban;

    @Column(name = "kichhoat", nullable = false)
    private Boolean kichhoat = true;

    @JsonIgnore
    @OneToMany(mappedBy = "sanpham")
    private List<HinhAnh> hinhanhs;
    

    @OneToMany(mappedBy = "sanpham", fetch = FetchType.LAZY)
    private List<GioHangChiTiet> giohangchitiets;

    @JsonIgnore
    @OneToMany(mappedBy = "sanpham")
    private List<DonHangChiTiet> donhangchitiets;

    @JsonIgnore
    @OneToMany(mappedBy = "sanpham")
    private List<DanhGia> danhgias;
}