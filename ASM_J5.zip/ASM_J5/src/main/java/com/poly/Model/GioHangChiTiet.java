package com.poly.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "giohangchitiet")
public class GioHangChiTiet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "magiohangchitiet")
    private Integer magiohangchitiet;


    //    @ManyToOne(fetch = FetchType.LAZY)
    @ManyToOne
    @JoinColumn(name = "taikhoan", nullable = false)
    private TaiKhoan taikhoan;


    @ManyToOne
    @JoinColumn(name = "masanpham", nullable = false)
    private SanPham sanpham;

    @Column(name = "soluong")
    private Integer soluong;

    public Float getTotal() {

        return this.sanpham.getDongia() * this.soluong;
    }
 
    // Getters and Setters
}