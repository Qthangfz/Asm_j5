package com.poly.Model;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "diachi")
public class DiaChi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "madiachi")
    private Integer madiachi;

    @ManyToOne
    @JoinColumn(name = "taikhoan", nullable = false)
    private TaiKhoan taikhoan;

    @Column(name = "sonhavaduong", nullable = false, columnDefinition = "NVARCHAR(255) default ''")
    private String sonhavaduong = "";

    @Column(name = "xaphuong", nullable = false, columnDefinition = "NVARCHAR(255) default ''")
    private String xaphuong = "";

    @Column(name = "quanhuyen", nullable = false, columnDefinition = "NVARCHAR(255) default ''")
    private String quanhuyen = "";

    @Column(name = "tinhthanhpho", nullable = false, columnDefinition = "NVARCHAR(255) default ''")
    private String tinhthanhpho = "";
    
    @NotEmpty(message="Vui lòng nhập số điện thoại")
    @Pattern( regexp = "^(0|\\+84|84)[1-9]{1}+[0-9]{8,9}$", 
	    message = "Vui lòng nhập số điện thoại hợp lệ"	)
    @Column(name = "sodienthoai", length = 15)
    private String sodienthoai;


    @Column(name = "macdinh", nullable = false, columnDefinition = "BIT default 0")
    private Boolean macdinh = false;

}