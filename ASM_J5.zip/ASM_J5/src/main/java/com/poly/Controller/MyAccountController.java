package com.poly.Controller;

import com.poly.Dao.*;
import com.poly.Model.GioHangChiTiet;
import com.poly.Model.TaiKhoan;
import com.poly.Model.SanPham;
import com.poly.Service.CookieService;
import com.poly.Service.SessionService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MyAccountController {
    @Autowired
    private SanPhamDao spDao;

    @Autowired
    private HinhAnhDao haDao;
    @Autowired
    private TaiKhoanDao tkDao;

    @Autowired
    private SessionService sessionService;
    TaiKhoan taiKhoanDaDangNhap;

    @Autowired
    private CookieService cookieService;

    @Autowired
    HttpServletRequest request;

    @Autowired
    private GioHangChiTietDao ghctDao;


    @GetMapping("/my-accout/add-to-cart/{id}")
    public String addToCart(@PathVariable String id, Model model,
                            @RequestParam("quantityToCart") int quantityToCart) {
        SanPham sanPhamDangXem = spDao.findByMasanpham(id);
        String tkDangNhap = sessionService.get("username");
        if (tkDangNhap != null) {
            taiKhoanDaDangNhap = tkDao.getOne(tkDangNhap);
            model.addAttribute("taiKhoanDaDangNhap", taiKhoanDaDangNhap);
            ghctDao.insertGioHangChiTiet(taiKhoanDaDangNhap.getTaikhoan(), id, quantityToCart);
        }else {
            return "redirect:/login";
        }
        model.addAttribute("sanPhamDangXem", sanPhamDangXem);
        return "redirect:/product-detail/" + id;
    }

    @GetMapping("/my-accout/view-cart")
    public String viewCart(Model model) {
        String tkdadangnhap = sessionService.get("username");
        if (tkdadangnhap != null) {
            taiKhoanDaDangNhap = tkDao.getOne(tkdadangnhap);
            model.addAttribute("taiKhoan", taiKhoanDaDangNhap);
            model.addAttribute("subTotalQuantity", ghctDao.calculateTotalQuantity(tkdadangnhap));
            model.addAttribute("countDistinctProductCodes", ghctDao.countDistinctProductCodes(tkdadangnhap));
            model.addAttribute("subTotalAmout", ghctDao.calculateSubtotal(tkdadangnhap));
            List<GioHangChiTiet> giohangs = ghctDao.findByTaikhoan(taiKhoanDaDangNhap.getTaikhoan());
            model.addAttribute("giohangs",giohangs);
        }
        return "/page/cart";
    }

    @GetMapping("my-account/cart/delete/{id}")
    public String deleteCart(@PathVariable("id") Integer id, Model model) {
        String tkdadangnhap = sessionService.get("username");
        if (tkdadangnhap != null) {
            taiKhoanDaDangNhap = tkDao.getOne(tkdadangnhap);
            model.addAttribute("taiKhoanDaDangNhap", taiKhoanDaDangNhap);
            ghctDao.delete(ghctDao.getOne(id));
        } else {
            return "redirect:/login";
        }
        return "redirect:/my-accout/view-cart";
    }


}
