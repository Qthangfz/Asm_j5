package com.poly.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Test {


    @GetMapping("product")
    public String product() {
        return "/page/product";
    }



    @GetMapping("cart")
    public String cart() {
        return "/page/cart";
    }

    @GetMapping("check-out")
    public String checkout() {
        return "/page/checkout";
    }

    @GetMapping("404")
    public String notFound() {
        return "/page/404";
    }

    @GetMapping("index")
    public String index() {
        return "/index2";
    }

}
