package com.poly.Controller;

import com.poly.Dao.DiaChiDao;
import com.poly.Dao.TaiKhoanDao;
import com.poly.Model.DiaChi;
import com.poly.Model.GioHangChiTiet;
import com.poly.Model.TaiKhoan;
import com.poly.Service.SessionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Controller
@RequestMapping("/address")
public class addresscontroller {

    @Autowired
    private SessionService sessionService;
    TaiKhoan taiKhoanDaDangNhap;

    @Autowired
    private DiaChiDao diaChiRepository;

    @Autowired
    private TaiKhoanDao tkDao;

    // Hiển thị danh sách địa chỉ
    @GetMapping
    public String listAddresses(Model model) {
        // Lấy tài khoản đang đăng nhập từ session
        String username = sessionService.get("username");
        TaiKhoan taiKhoanDaDangNhap = tkDao.findById(username)
                .orElseThrow(() -> new RuntimeException("Tài khoản không tồn tại"));

        // Tìm tất cả địa chỉ của tài khoản đã đăng nhập
        List<DiaChi> diaChiList = diaChiRepository.findByTaikhoan(taiKhoanDaDangNhap);

        model.addAttribute("addresses", diaChiList);
        model.addAttribute("address", new DiaChi()); // Đối tượng rỗng để thêm mới
        return "page/address";
    }


    // Lưu địa chỉ mới
    @PostMapping("/save")
    public String saveAddress(@Valid @ModelAttribute("address") DiaChi address, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("addresses", diaChiRepository.findAll());
            return "page/address";
        }


        String tkdadangnhap = sessionService.get("username");
        if (tkdadangnhap != null) {
            taiKhoanDaDangNhap = tkDao.getOne(tkdadangnhap);
            address.setTaikhoan(taiKhoanDaDangNhap); // Gán tài khoản đang đăng nhập vào địa chỉ
        }else {
           model.addAttribute("errorMessage", "Không thể xác định tài khoản người dùng hiện tại.");
           model.addAttribute("addresses", diaChiRepository.findAll());
           return "page/address";
        }


        model.addAttribute("successMessage", "Lưu địa chỉ thành công");
        diaChiRepository.save(address);
        return "redirect:/address";
    }


    // Chỉnh sửa địa chỉ
    @GetMapping("/edit/{id}")
    public String editAddress(@PathVariable("id") Integer id, Model model) {
        DiaChi address = diaChiRepository.findById(id).orElse(null);
        if (address == null) {
            // Thêm thông báo lỗi hoặc chuyển hướng nếu không tìm thấy địa chỉ
            return "redirect:/address"; // Redirect về trang danh sách
        }
        model.addAttribute("address", address); // Đối tượng để sửa
        return "page/editAddress"; // Trang sửa riêng biệt
    }

    // Xóa địa chỉ
    @GetMapping("/delete/{id}")
    public String deleteAddress(@PathVariable("id") Integer id, Model model) {
        // Kiểm tra xem địa chỉ có tồn tại không
        if (!diaChiRepository.existsById(id)) {
            model.addAttribute("errorMessage", "Địa chỉ không tồn tại!");
            return "redirect:/address"; // Chuyển hướng về trang danh sách với thông báo lỗi
        }

        try {
            // Thực hiện xóa địa chỉ
            diaChiRepository.deleteById(id);
            model.addAttribute("successMessage", "Địa chỉ đã được xóa thành công!");
        } catch (Exception e) {
            // Xử lý lỗi nếu không thể xóa, ví dụ như lỗi ràng buộc dữ liệu
            model.addAttribute("errorMessage", "Không thể xóa địa chỉ này do có ràng buộc dữ liệu!");
        }

        return "redirect:/address";
    }

}
