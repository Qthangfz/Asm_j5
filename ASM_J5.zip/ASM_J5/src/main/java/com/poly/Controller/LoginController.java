package com.poly.Controller;

import com.poly.Dao.DangNhapDao;
import com.poly.Dao.TaiKhoanDao;
import com.poly.Model.DangNhap;
import com.poly.Service.CookieService;
import com.poly.Service.MD5EnCoder;
import com.poly.Model.TaiKhoan;
import com.poly.Service.SessionService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Date;

@Controller
public class LoginController {
    @Autowired
    private MD5EnCoder md5;

    @Autowired
    private SessionService  sessionService;
    @Autowired
    private HttpServletResponse response;

    @Autowired
    private CookieService cookieService;
    @Autowired
    private DangNhapDao dnDao;
    @Autowired
    private TaiKhoanDao tkDao;
    @Autowired
    HttpServletRequest request;

    @GetMapping("/login")
    public String showFormLogin(Model model) {
        DangNhap dangNhap = new DangNhap();
        if(cookieService.get("taiKhoanGhiNho")!=null) {
            model.addAttribute("taiKhoanGhiNho",cookieService.getValue("taiKhoanGhiNho"));
            model.addAttribute("matKhauGhiNho",cookieService.getValue("matKhauGhiNho"));

            model.addAttribute("checkBoxGhiNho",true);
        }else {
            model.addAttribute("checkBoxGhiNho",false);
        }
        model.addAttribute("dangNhap", new DangNhap());
        return "/page/login";
    }

    @PostMapping("/login")
    public String login(Model model, @Validated @ModelAttribute("dangNhap") DangNhap dangNhap, BindingResult result,
                        RedirectAttributes redirectAttributes ) {
        if (result.hasErrors()) {
            return "/page/login";
        }

        String identifier = dangNhap.getIdentifier();
        DangNhap user = dnDao.findByUsernameOrEmailAndPassword(identifier, md5.getMD5Hash(dangNhap.getMatkhau()));
        if (user != null && user.getKichhoat()) {
            // Đăng nhập thành công
            TaiKhoan tk = tkDao.findById(user.getTaikhoan())
                    .orElseThrow(() -> new RuntimeException("TaiKhoan not found"));
            tk.setLandangnhapcuoi(new Date());
            tkDao.save(tk);
            sessionService.set("username", user.getTaikhoan());
            model.addAttribute("loginSuccess", true);
            redirectAttributes.addFlashAttribute("loginSuccess", true);

            if (dangNhap.isRememberme()) {
                cookieService.add("taiKhoanGhiNho", dangNhap.getIdentifier(), 60);
                cookieService.add("matKhauGhiNho", dangNhap.getMatkhau(), 60);
            } else {
                cookieService.remove("taiKhoanGhiNho");
                cookieService.remove("matKhauGhiNho");
            }
            model.addAttribute("loginSuccess", true);
            return "/page/login";
        }
        model.addAttribute("loginFailed", true);
        return "/page/login";
    }


}
