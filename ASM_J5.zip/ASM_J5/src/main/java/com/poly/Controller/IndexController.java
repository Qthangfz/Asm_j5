package com.poly.Controller;

import com.poly.Dao.GioHangChiTietDao;
import com.poly.Dao.SanPhamDao;
import com.poly.Dao.TaiKhoanDao;
import com.poly.Model.GioHangChiTiet;
import com.poly.Model.SanPham;
import com.poly.Model.TaiKhoan;
import com.poly.Service.SessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Controller
public class IndexController {

    @Autowired
    private TaiKhoanDao tkDao;
    @Autowired
    private SanPhamDao sanPhamDao;
    @Autowired
    private SessionService sessionService;
    TaiKhoan taiKhoanDangNhap;
    @Autowired
    private GioHangChiTietDao ghctDao;

    @GetMapping()
    public String Userindex(Model model ) {
        String tkdadangnhap = sessionService.get("username");
        if (tkdadangnhap != null) {
            taiKhoanDangNhap = tkDao.getOne(tkdadangnhap);
            model.addAttribute("taiKhoan", taiKhoanDangNhap);
            model.addAttribute("subTotalQuantity", ghctDao.calculateTotalQuantity(tkdadangnhap));
            model.addAttribute("countDistinctProductCodes", ghctDao.countDistinctProductCodes(tkdadangnhap));
            model.addAttribute("subTotalAmout", ghctDao.calculateSubtotal(tkdadangnhap));
            List<GioHangChiTiet> giohangs = ghctDao.findByTaikhoan(taiKhoanDangNhap.getTaikhoan());
            model.addAttribute("giohangs",giohangs);
        }
        List<SanPham> products = sanPhamDao.findAll();
        model.addAttribute("products", products);
        return "/page/main";
    }

    @GetMapping("product-detail/{id}")
    public String Productdetail(@PathVariable("id") String id, Model model) {
        SanPham sanPhamDangXem = sanPhamDao.findByMasanpham(id);
        String tkdadangnhap = sessionService.get("username");
        if (tkdadangnhap != null) {
            taiKhoanDangNhap = tkDao.getOne(tkdadangnhap);
            model.addAttribute("taiKhoan", taiKhoanDangNhap);
            model.addAttribute("subTotalQuantity", ghctDao.calculateTotalQuantity(tkdadangnhap));
            model.addAttribute("countDistinctProductCodes", ghctDao.countDistinctProductCodes(tkdadangnhap));
            model.addAttribute("subTotalAmout", ghctDao.calculateSubtotal(tkdadangnhap));
            List<GioHangChiTiet> giohangs = ghctDao.findByTaikhoan(taiKhoanDangNhap.getTaikhoan());
            model.addAttribute("giohangs",giohangs);
        }
        if (sanPhamDangXem == null) {
            return "page/404";
        }
        model.addAttribute("sanPhamDangXem", sanPhamDangXem);
        return "page/product-detail";
    }

}
