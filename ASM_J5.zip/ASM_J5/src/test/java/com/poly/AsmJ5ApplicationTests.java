package com.poly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsmJ5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
